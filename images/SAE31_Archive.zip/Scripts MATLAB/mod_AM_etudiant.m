clear;
clc;
close;
%% Initialisation des variables
fp=10000; %fréquence porteuse (Hz)
Ep=5;    %amplitude de la porteuse

fm=500;  %fréquence du modulant sinusoïdal
Tm=1/fm;

m=0.5;   %indice de modulation

fe=100000;    %fréquence échantillonnage
Te=1/fe; %période d'échantillonnage   
Ne=2000;  %nombre de points de simulation

t=(0:Ne-1)*Te;

%% Création des différents signaux: modulant, porteuse et signal AM


%% Affichage des chronogrammes
subplot(2,1,1) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t*1000,signal_MLT3,"b"); %t en ms
title('représentation du chronogramme du signal MLT3')
xlabel('t(ms)')
ylabel('Volt')
legend('MLT3(t)')
axis([0 1000*10/D -20 20])  %affichage de 10 symboles
grid on
%% Calcul puis affichage des spectres 
