clear;
clc;
close;
%% Initialisation des variables
D=20000;  %débit en bits/s
fp = 2.406e9; %fréquence porteuse (Hz);
Tb=1/D; %durée d'un bit
R=1/2*D;    %Rapidité
Ts=Tb;  %durée d'un symbole
M = 4; 

  

Nb=1024;   % nombre de bits à transmettre
Nech_symb=32;    %nombre déchantillons par symbole
Nech=Nb * Nech_symb;
Tmax=Nb*Tb;        %durée totale de la trame 
Nyquist = 0.4;
fe=Nech_symb * D;    %fréquence échantillonnage
Te=1/fe; %période d'échantillonnage 
t = (0:Nech-1) * Te;


data = randi([0 M-1],Nb,1); % création des nombres aléatoires
data = rectpulse(data, Nech_symb); %fait 32 échantillons pour chaque bit (à commenter pour tester le filtre de Nyquist
data_mod = pskmod(data, M, pi/M); %modulation en mpsk
% filtreNyquist = comm.RaisedCosineTransmitFilter('Shape','Normal','RolloffFactor', Nyquist,'OutputSamplesPerSymbol',Nech_symb, 'Gain', sqrt(Nech_symb));
% signal_Nyquist = filtreNyquist(data_mod).';
% 
% Bruit = comm.AWGNChannel;
% signal_bruit = Bruit(data_mod);
% 
ModulPhase = comm.PhaseFrequencyOffset("FrequencyOffset", 100000); % "PhaseOffset", 35
signal_module = ModulPhase(data_mod); 

signal_utile = signal_module; %à changer en fonction du signal à tester
%% Configuration de l'ADALM PLUTO émetteur
% tx = sdrtx('Pluto', 'RadioID', 'usb:0', 'CenterFrequency', fp,'BasebandSampleRate', fe);
% release(tx); % réinitialisation de l’Adalm Pluto 
% 
% transmitRepeat(tx, data_mod); % émission du signal: c.' est le transposé de c car la fonction émet des vecteurs colonne


%% Création des signaux I et Q
I = round(real(signal_utile),3);
Q = round(imag(signal_utile),3);




%% Création de la constellation
constellation = comm.ConstellationDiagram;
constellation(signal_utile);

%% Affichage du chronogramme des signaux I et Q
subplot(3,1,1) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t*1000,I,"b"); %t en ms
title('représentation du chronogramme du signal I')
xlabel('t(ms)')
ylabel('Volt')
legend('I(t)')
axis([0 3 -1 1])  %affichage de 10 symboles
grid on

subplot(3,1,2) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t*1000,Q,"b"); %t en ms
title('représentation du chronogramme du signal Q')
xlabel('t(ms)')
ylabel('Volt')
legend('Q(t)')
axis([0 3 -1 1])  %affichage de 10 symboles
grid on

%% affichage du spectre du signal modulé

% 
% [X f]=spectre(data_mod.',fe,Nech); %prend la sortie dans des variables X et f de la fonction spectre
% subplot(4,1,3);
% plot(f,X,"b");
% axis([0 10*D -60 10])  %affichage de 10 symboles
% 
% title('Spectre en amplitude du signal modulé')
% xlabel('f(Hz)')
% ylabel('Volt')
% legend('|Data_Mod(f)|')
% grid on


[X f]=spectre(signal_utile.',fe,Nech); %prend la sortie dans des variables X et f de la fonction spectre
subplot(3,1,3);
plot(f,X,"b");
axis([0 4*D -70 10])  %affichage de 10 symboles
title('Spectre du signal')
xlabel('f(Hz)')
ylabel('Volt')
legend('|Data_Mod(f)|')
grid on