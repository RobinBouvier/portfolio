%% Remise à zéro du contexte
clear ;
clc ;
close ;
%% initialisation des variables
fp = 2.406017e9;  %fréquence de la porteuse: à modifier selon votre numéro de canal
Fech = 640000; %fréquence d'échantillonnage du signal c(t) transmis à l'Adalm Pluto
Nech= 16000; % nombre d'échantillons à transmettre
Nech_symbol = 32;
Tech = 1/Fech;
t=(0:Nech-1)*Tech;
Preambule = [1 1 1 1 1 0 0 1 1 0 1 0 1]';
df = 200000;
%% configuration de l'ADALM PLUTO récepteur
rx = sdrrx('Pluto', 'RadioID', 'usb:0', 'CenterFrequency', fp, ...
           'BasebandSampleRate', Fech, 'SamplesPerFrame', Nech * 2, ...
           'OutputDataType', 'double', 'ShowAdvancedProperties', true);
 
 
%% Réception des échantillons       
reception= rx(); % réception d'une trame de Nech échantillons
reception= reception.';   % on prend la transposée pour avoir un vecteur colonne...

%% démodumation
data_demod = fskdemod(reception,2,df,Nech_symbol,Fech);
data_demod = data_demod.';

%% détection préambule
detecteur = comm.PreambleDetector(Preambule, 'Input', 'Bit');
indice_preambule = detecteur(data_demod);



%% récupération du message 
 nombre_bitsmsg =  data_demod(indice_preambule(2)+1: indice_preambule(2)+16);
 nombre_bitsmsg = nombre_bitsmsg.';
 nombre_bitsmsg =num2str(nombre_bitsmsg);
 nombre_bitsmsg_dec = bin2dec(nombre_bitsmsg);

m = data_demod(indice_preambule(2)+17: indice_preambule(2)+16+nombre_bitsmsg_dec);
 
m_reshape = reshape(m, 7, []);
m_final = '';
for col = 1:size(m_reshape, 2)
     bit_sequence = m_reshape(:, col);
     
     bit_str = num2str(bit_sequence', '%d');
     bit_str = strrep(bit_str, ' ', ''); %enleve les espaces
     lettre = char(bin2dec(bit_str));
     m_final = [m_final lettre];
 end
 m_finalCRC = data_demod(indice_preambule(2)-28: indice_preambule(2)+16+nombre_bitsmsg_dec+3);
 m_finalSansCRC = data_demod(indice_preambule(2)-28: indice_preambule(2)+16+nombre_bitsmsg_dec);
%%verif crc
CRC_Polynome =[1 0 0 1];
crcDetection = comm.CRCDetector(CRC_Polynome, "ChecksumsPerFrame", 1);

[~, err] = crcDetection(m_finalCRC);

if err == 0
     disp("Le message est conforme")
else 
    disp("Le message est faux")
end



 disp(m_final);

% %% Affichage du chronogramme de la réception
% subplot(2,2,3) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
% plot(t*1000,reception,"b"); %t en ms
% title('représentation du chronogramme de la reception')
% xlabel('t(ms)')
% ylabel('Volt')
% legend('reception(t)')
% axis([0 1 -1 1])  %affichage de 10 symboles
% grid on
% 
% %% Calcul puis affichage du spectre de la réception
% [X f]=spectre(reception,Fech,Nech); %prend la sortie dans des variables X et f de la fonction spectre
% subplot(2,2,4);
% plot(f,X,"b");
% title('Spectre en amplitude de la réception')
% xlabel('f(Hz)')
% ylabel('dB')
% legend('|reception(f)|')
% axis([0 5e5 -100 0])  %affichage entre 0 et 2*D (Hz)
% grid on