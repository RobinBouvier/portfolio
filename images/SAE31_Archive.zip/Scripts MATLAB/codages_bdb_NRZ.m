%% 
clear; %supprime les variables
clc; %supprime le contenu de l'invite de commande
close; %ferme la fenêtre d'affichage
%% Définition des variables
D=1000;          %débit en bits/s
Nech_bit=40;    % nombre d'échantillons par symbole; doit être pair.
fe=D*Nech_bit;  %fréquence d'échantillonnage.

Te=1/fe;  % période d'échantillonnage
Tb=1/D;   % durée d'un bit

data=[0 1 1 1 0 1 1 0 0 0 0 0 0 0  1 0 ];  %séquence utilisateur de 10 bits
alea=randi([0 1],1,10000);%genère un tableau de une valeur qui prend soit 1 soit 0 sur 10000 colonnes 
data=[data alea];  %ajoute 10000 bits aléatoires
                                         %après la séquence utilisateur

Nb=size(data,2);          %Nb de bits à transmettre
Nech=Nech_bit*Nb;        %nombre total d'échantillons  
Tmax=Nb*Tb;               %durée de la trame

t=0:Te:Tmax-Te;           %vecteur temps constitué de Ns*Nb échantilllons   


%% Création du signal NRZ
signal_NRZ=[];             %initialisation du signal codé en NRZ
symbole_1=5*ones(1,Nech_bit); % retourne un tableau de 1 ligne avec un nombre de colonnes Nech avec que des 5 
symbole_0=-5*ones(1,Nech_bit);% retourne un tableau de 1 ligne avec un nombre de colonnes Nech avec que des -5 

for n=1:Nb      %codage des différents bits
     if (data(n)==1) %la boucle itère toutes les valeurs de data et vérifie la condition = 1
        signal_NRZ=[signal_NRZ symbole_1]; % le signal NRZ de sortie prend la valeur au n argument correspondant au n argument de symbole_1 soit 5
     else
        signal_NRZ=[signal_NRZ symbole_0];% le signal NRZ de sortie prend la valeur au n argument correspondant au n argument de symbole_0 soit -5 
     end
    
end   


%% Affichage du chronogramme du signal NRZ
subplot(2,1,1) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t*1000,signal_NRZ,"b"); %t en ms
title('représentation du chronogramme du signal NRZ')
xlabel('t(ms)')
ylabel('Volt')
legend('NRZ(t)')
axis([0 1000*10/D -10 10])  %affichage de 10 symboles
grid on


%% Calcul puis affichage du spectre su signal NRZ 
[X f]=spectre(signal_NRZ,fe,Nech); %prend la sortie dans des variables X et f de la fonction spectre
subplot(2,1,2);
plot(f,X,"b");
title('Spectre en amplitude du signal codé en NRZ')
xlabel('f(Hz)')
ylabel('Volt')
legend('|NRZ(f)|')
axis([0 4*D -60 0])  %affichage entre 0 et 2*D (Hz)
grid on

