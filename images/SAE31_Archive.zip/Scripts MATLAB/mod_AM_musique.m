clear;
clc;
close;
%% Initialisation des variables
fp = 10000; % fréquence porteuse (Hz)
Ep = 5;    % amplitude de la porteuse

fm = 500;  % fréquence du modulant sinusoïdal
Tm = 1 / fm;

m = 1;   % indice de modulation

fe = 100000;    % fréquence échantillonnage
Te = 1 / fe; % période d'échantillonnage   
Ne = 2000;  % nombre de points de simulation

t = (0:Ne-1) * Te;

%% Création des différents signaux: modulant, porteuse et signal AM
porteuse = Ep * cos(2 * pi * fp * t); % création de la porteuse
[modulant, fs] = audioread("musique.mp4", [100001, 102000]); % création du modulant (ici la musique)

%% Normalisation du signal audio

modulant_centre = modulant - mean(modulant); % Centrage du signal autour de 0

modulant_cc = max(modulant_centre) - min(modulant_centre); % Amplitude crête à crête
modulant_norm = modulant_centre * (2 / modulant_cc); % Normalisation pour une amplitude crête à crête de 2V

%% Signal AM
signalAM = (1 + m * modulant_norm') .* porteuse; % Calcul du signal AM (attention à la dimension du vecteur modulant)

%% Affichage des chronogrammes
subplot(4,1,1) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t*1000,modulant,"b"); %t en ms
title('représentation du chronogramme du modulant')
xlabel('t(ms)')
ylabel('Volt')
legend('A(t)')
axis([0 20 -1 1])  %affichage de 5 période du signal AM
grid on
%% Affichage des chronogrammes
subplot(4,1,2) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t*1000,modulant_norm,"b"); %t en ms
title('représentation du chronogramme du modulant normalisé')
xlabel('t(ms)')
ylabel('Volt')
legend('A(t)')
axis([0 20 -2 2])  %affichage de 5 période du signal AM
grid on
%% Affichage des chronogrammes
subplot(4,1,3) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t*1000,signalAM,"b"); %t en ms
title('représentation du chronogramme de la modulation AM')
xlabel('t(ms)')
ylabel('Volt')
legend('A(t)')
axis([0 20 -10 10])  %affichage de 5 période du signal AM
grid on
%% Calcul puis affichage des spectres 
[X f]=spectre(signalAM,fe,Ne); %prend la sortie dans des variables X et f de la fonction spectre
subplot(4,1,4);
plot(f,X,"b");
title('Spectre en amplitude du signal AM')
xlabel('f(Hz)')
ylabel('Volt')
legend('|signalAM(f)|')
axis([0 50000 -100 50])  %affichage entre 8500 et 11500 (Hz)
grid on