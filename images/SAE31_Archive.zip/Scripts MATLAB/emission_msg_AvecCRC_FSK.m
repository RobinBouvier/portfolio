%% 
clear; %supprime les variables
clc; %supprime le contenu de l'invite de commande
close; %ferme la fenêtre d'affichage
%% Définition des variables
D=20000;          %débit en bits/s
Nech_symbole=32;    % nombre d'échantillons par symbole doit être pair.
fe=D*Nech_symbole;  %fréquence d'échantillonnage.
Tb=1/D;   % durée d'un bit
fp = 2.406e9;
Te= Tb / Nech_symbole;  % période d'échantillonnage


synchro = [1 0 1 0 1 0 1 0 1 0 1 0 1 0 1 0];
preambule = [1 1 1 1 1 0 0 1 1 0 1 0 1];

m=[1 0 1 0 1 1 0 1 0];  %séquence utilisateur de 9 bits
%alea=ones(1,20);%genère un tableau de une valeur qui prend soit 1 soit 0 sur 10000 colonnes 
%m=[m alea];  %ajoute 10000 bits aléatoires
                                         %après la séquence utilisateur

message = 'salut'; %ne pas mettre d'espace sivouplé
message_char = char(message);
%%Mettre le message en binaire 
msg_ascii = [];
for n=1:length(message_char)
    caractere = double(message(n));
    msg_ascii = [msg_ascii caractere];
end
disp(msg_ascii)
msg_dec = [];
for n=1:length(msg_ascii)
    caractere_dec = dec2bin(msg_ascii(n));
    caractere_dec = double(caractere_dec) - double('0');
    msg_dec = [msg_dec caractere_dec];
end
disp(msg_dec)

msg_dec = reshape(msg_dec, [], 1);
msg_dec = msg_dec.';

longueur_message = length(msg_dec);               % Longueur du message en nombre de bits
disp(longueur_message)
longueur_binaire = dec2bin(longueur_message, 16);  % Conversion en binaire sur 16 bits
longueur_binaire = double(longueur_binaire) - double('0'); % Conversion en vecteur binaire
disp(longueur_binaire)

msg_final = [synchro preambule longueur_binaire msg_dec] ;

% Polygone de CRC choisi ici comme exemple, vous pouvez choisir un autre.
CRC_polynomial = [1 0 0 1];
crcGen = comm.CRCGenerator(CRC_polynomial, 'ChecksumsPerFrame', 1);

msg_final_crc = crcGen(msg_final.');
msg_final_crc = msg_final_crc.';
%msg_final_crc = [1	0	1	0	1	0	1	0	1	0	1	0	1	0	1	0	1	1	1	1	1	0	0	1	1	0	1	0	1	0	0	0	0	0	0	0	0	0	0	1	1	1	0	0	0	1	1	1	0	0	1	1	1	1	0	0	0	0	1	1	1	0	1	1	0	0	1	1	1	0	1	0	1	1	1	0	0	1	1	1	1	1	0	0	1	1	0	1	1	1	0	1	0	0	1	1	1	0	1	0	1];
%message avec une erreur dans le CRC


Nb=size(msg_final_crc,2);          %Nb de bits à transmettre
Nech=Nech_symbole*Nb;        %nombre total d'échantillons  
Tmax=Nb*Tb;               %durée de la trame
deltaf = 100e3;
t = (0:Nech-1) * Te;


%% Création du signal   


signal_NRZ=[];             %initialisation du signal codé en NRZ
symbole_1=1*ones(1,Nech_symbole); % retourne un tableau de 1 ligne avec un nombre de colonnes Nech avec que des 5 
symbole_0=0*ones(1,Nech_symbole);% retourne un tableau de 1 ligne avec un nombre de colonnes Nech avec que des -5 

for n=1:Nb      %codage des différents bits
     if (msg_final_crc(n)==1) %la boucle itère toutes les valeurs de data et vérifie la condition = 1
        signal_NRZ=[signal_NRZ symbole_1]; % le signal NRZ de sortie prend la valeur au n argument correspondant au n argument de symbole_1 soit 5
     else
        signal_NRZ=[signal_NRZ symbole_0];% le signal NRZ de sortie prend la valeur au n argument correspondant au n argument de symbole_0 soit -5 
     end
    
end   




FSK1 = exp(1j*2 * pi * deltaf * t);
FSK0 =  exp(-1j*2 * pi * deltaf * t);

Signal_C = FSK1 .* signal_NRZ + FSK0 .* (1 - signal_NRZ);



   

%% Affichage du chronogramme du signal NRZ
subplot(4,2,1) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t,signal_NRZ,"b"); %t en ms
title('représentation du chronogramme du signal NRZ')
xlabel('t(ms)')
ylabel('Volt')
legend('NRZ(t)')
axis auto  %affichage de 10 symboles
grid on


%% Configuration de l'ADALM PLUTO émetteur
tx = sdrtx('Pluto', 'RadioID', 'usb:0', 'CenterFrequency', fp,'BasebandSampleRate', fe);
release(tx); % réinitialisation de l’Adalm Pluto 

transmitRepeat(tx, Signal_C.'); % émission du signal: c.' est le transposé de c car la fonction émet des vecteurs colonne

%% Affichage du chronogramme du signal NRZ
subplot(4,2,3) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t,real(Signal_C),"b"); %t en ms
title('I(t)')
xlabel('t(ms)')
ylabel('Volt')
legend('NRZ(t)')
axis ([0 Te*288*2 -2 +2])  %affichage de 10 symboles
grid on

subplot(4,2,4) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t,imag(Signal_C),"b"); %t en ms
title('Q(t)')
xlabel('t(ms)')
ylabel('Volt')
legend('NRZ(t)')
axis ([0 Te*288*2 -2 +2])  %affichage de 10 symboles
grid on

% Calcul puis affichage du spectre su signal NRZ 
[X f]=spectre(Signal_C,fe,Nech); %prend la sortie dans des variables X et f de la fonction spectre
subplot(4,2,5);
plot(f,X,"b");
title('Spectre en amplitude du signal codé en NRZ')
xlabel('f(Hz)')
ylabel('Volt')
legend('|NRZ(f)|')
axis([0 4*D -60 0])  %affichage entre 0 et 2*D (Hz)
grid on

