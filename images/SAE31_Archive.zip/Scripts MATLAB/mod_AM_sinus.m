clear;
clc;
close;
%% Initialisation des variables
D=1000;          %débit en bits/s

fp=10000; %fréquence porteuse (Hz)
Ep=5;    %amplitude de la porteuse

fm=500;  %fréquence du modulant sinusoïdal
Tm=1/fm;

m=0.5;   %indice de modulation

fe=100000;    %fréquence échantillonnage
Te=1/fe; %période d'échantillonnage   
Ne=2000;  %nombre de points de simulation

t=(0:Ne-1)*Te;

%% Création des différents signaux: modulant, porteuse et signal AM
porteuse = Ep * cos(2 * pi * fp * t); %création de la porteuse
modulant = cos(2 * pi * fm * t); %création du modulant
signalAM = Ep * (1 + m .* modulant) .* porteuse; %on crée le signal AM avec la porteuse et le modulant

%% Affichage des chronogrammes
subplot(2,1,1) %2 est est le nombre de ligne, 1 le nombre de colonne et 1 la position
plot(t*1000,signalAM,"b"); %t en ms
title('représentation du chronogramme de la modulation AM')
xlabel('t(ms)')
ylabel('Volt')
legend('A(t)')
axis([0 10 -50 50])  %affichage de 5 période du signal AM
grid on
%% Calcul puis affichage des spectres 
[X f]=spectre(signalAM,fe,Ne); %prend la sortie dans des variables X et f de la fonction spectre
subplot(2,1,2);
plot(f,X,"b");
title('Spectre en amplitude du signal AM')
xlabel('f(Hz)')
ylabel('Volt')
legend('|signalAM(f)|')
axis([8500 11500 -300 50])  %affichage entre 8500 et 11500 (Hz)
grid on